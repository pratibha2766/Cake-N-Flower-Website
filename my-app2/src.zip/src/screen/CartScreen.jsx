import React from 'react'
import {Container,Row,Col} from 'react-bootstrap'
import { useSelector } from 'react-redux'
const CartScreen = () => {
    const cartState=useSelector(state=> state.cartReducer)
    const cartItems =cartState.cartItems
    return (
        <>
            <Container>
                <Row>
                    <Col md={6}>
                        <h1>Cart Items</h1>
                        <Row>
                            {
                                cartItems.map(item=>(
                                    <>
                                    <Col md={7}>
                                        <h6>{item.name}{item.varient}</h6>
                                        <h5>Price:{item.quantity}X{item.prices[0][item.varient]}={""}</h5>
                                        <h6>Quantity:{item.quantity}</h6>
                                    </Col>
                                    <Col md={5}>
                                        <img alt={item.name} src={item.image} style={{width:"80px"}}/>
                                    </Col>
                                    <hr/>
                                    </>

                                ))
                            }
                        </Row>
                    </Col>
                    
                </Row>
            </Container>
            
        </>
    )
}

export default CartScreen
