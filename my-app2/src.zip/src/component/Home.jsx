import React from 'react';
//import './Home.css'
const Home = () => {
    const handler=() =>{
        window.location.href='/'

    }
    return (
        <div classNameName="hero" style={{ backgroundImage: 'url(http://cdn26.us1.fansshare.com/photo/backgrounddesigns/home-design-pastel-colors-tumblr-background-midcentury-large-the-eclectic-expansive-elegant-with-pastel-design-design-interior-website-decorating-websites-ideas-for-bedrooms-background-designs-1224733871.jpg)'}}>
            <div class="row row-cols-1 row-cols-md-2 g-4">
                <div class="col" >
                    <div className="card h-100" style={{width: "33rem", marginLeft:"5rem"}}>
                        <img src="assets/cake.jpg" class="card-img-top"/>
                        <div class ="card-body">
                        <h5 class ="card-title"> Cakes</h5>
                        <p class ="card-text">Count the memories <br/>Not the Calories.</p>
                        <button onClick={handler}>Explore Cakes</button>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="card h-100" style={{width: "33rem"}}>
                        <img src="assets/flowers.jpg" class="card-img-top"/>
                        <div class ="card-body">
                        <h5 class ="card-title">Flowers</h5>
                        <p class ="card-text">Your mind is a garden.Your Thoughts are seeds..You can grow flowers or you can grow weeds.</p>
                        <button onClick={handler}>Explore Flowers</button>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="card h-100" style={{width: "33rem",marginLeft:"5rem"}}>
                        <img src="assets/combo.jpg" class="card-img-top"/>
                        <div class ="card-body">
                        <h5 class ="card-title">Explore Combos</h5>
                        <p class ="card-text">Every flower must grow through dirt<br/>Make Your Day better with delicious dessert!!.</p>
                        <button onClick={handler}>Explore Combos</button>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="card h-100" style={{width: "33rem"}}>
                        <img src="assets/all.jpg" class="card-img-top"/>
                        <div class ="card-body">
                        <h5 class ="card-title">Explore Varities</h5>
                        <p class ="card-text">Cakes,Flowers,Combos.</p>
                        <button onClick={handler}>Explore ALL</button>
                        </div>
                    </div>
                </div>
            </div>
            
        </div>
    )
}

export default Home
