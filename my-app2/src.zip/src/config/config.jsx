import  firebase from 'firebase/compat/app'
import 'firebase/compat/auth'
import 'firebase/compat/firestore'
import 'firebase/compat/storage'
//import {initializeApp} from 'firebase/app'
const firebaseConfig = {
    apiKey: "AIzaSyC-XtwYvpflAsBYBtFJYsxFwDdnT9gaAog",
    authDomain: "cakeflowers-website.firebaseapp.com",
    projectId: "cakeflowers-website",
    storageBucket: "cakeflowers-website.appspot.com",
    messagingSenderId: "497602239787",
    appId: "1:497602239787:web:ca898434ef09c3c48bf96e"
  };

  firebase.initializeApp(firebaseConfig);

  const auth=firebase.auth();
  const db= firebase.firestore();
  const storage = firebase.storage();

  export{auth,db,storage}
